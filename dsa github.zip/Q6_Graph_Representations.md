# Q6: Social Network Graph — Adjacency Matrix vs Adjacency List

**Graph:** Vertices {A, B, C, D, E, F}
**Edges:** A–B, A–C, B–D, B–E, C–F, E–F (V = 6, E = 6, undirected)

```
        A
       / \
      B   C
     / \   \
    D   E---F
```

---

## a) Implementation

### Adjacency Matrix (Python)

```python
vertices = ['A', 'B', 'C', 'D', 'E', 'F']
edges = [('A','B'), ('A','C'), ('B','D'), ('B','E'), ('C','F'), ('E','F')]
n = len(vertices)
idx = {v: i for i, v in enumerate(vertices)}

matrix = [[0]*n for _ in range(n)]
for u, v in edges:
    i, j = idx[u], idx[v]
    matrix[i][j] = 1
    matrix[j][i] = 1
```

**Resulting matrix:**

```
   A B C D E F
A [0,1,1,0,0,0]
B [1,0,0,1,1,0]
C [1,0,0,0,0,1]
D [0,1,0,0,0,0]
E [0,1,0,0,0,1]
F [0,0,1,0,1,0]
```

### Adjacency List (Python)

```python
adj_list = {v: [] for v in vertices}
for u, v in edges:
    adj_list[u].append(v)
    adj_list[v].append(u)
```

**Resulting list:**

```
A: ['B', 'C']
B: ['A', 'D', 'E']
C: ['A', 'F']
D: ['B']
E: ['B', 'F']
F: ['C', 'E']
```

### BFS and DFS from vertex A

```python
def bfs_matrix(start):
    visited = [False]*n
    order, ops = [], 0
    queue = [idx[start]]
    visited[idx[start]] = True
    while queue:
        u = queue.pop(0)
        order.append(vertices[u])
        for v in range(n):                 # scans ALL n columns every time
            ops += 1
            if matrix[u][v] == 1 and not visited[v]:
                visited[v] = True
                queue.append(v)
    return order, ops

def bfs_list(start):
    visited = {v: False for v in vertices}
    order, ops = [], 0
    queue = [start]
    visited[start] = True
    while queue:
        u = queue.pop(0)
        order.append(u)
        for v in adj_list[u]:              # scans only actual neighbours
            ops += 1
            if not visited[v]:
                visited[v] = True
                queue.append(v)
    return order, ops
```

(DFS mirrors this using recursion/a stack instead of a queue.)

**Execution results (both representations give the same traversal order, since it depends on graph structure, not representation):**

| Traversal | Order from A |
|---|---|
| BFS | A → B → C → D → E → F |
| DFS | A → B → D → E → F → C |

---

## b) Search operation — locating a specified vertex

A "search" here means locating a vertex label within the structure (e.g., checking membership / preparing to access it), and separately, checking whether an **edge** exists between two vertices — the operation adjacency matrices and lists are really optimized for.

**Vertex lookup** (scanning the vertex set/dict keys) — both need a linear scan of at most V entries:

| Target vertex | Matrix comparisons | List comparisons |
|---|---|---|
| E | 5 | 5 |
| F | 6 | 6 |

**Edge check B–F (does an edge exist?)** — this is where the representations diverge:

| Operation | Adjacency Matrix | Adjacency List |
|---|---|---|
| Check edge B–F | 1 (direct index `matrix[B][F]`) | 3 (scan B's neighbour list `[A, D, E]`) |
| Result | False | False |

This is the key structural difference: **matrix edge-lookup is O(1)**; **list edge-lookup is O(degree(u))**.

---

## c) Analysis and Comparison

### Execution results from the code above

| Metric | Adjacency Matrix | Adjacency List |
|---|---|---|
| Storage cells used (V=6, E=6) | V² = 36 | 2E = 12 |
| BFS from A — operations (cell/neighbour checks) | 36 | 12 |
| DFS from A — operations | 36 | 12 |
| Edge check (B–F) operations | 1 | 3 |
| Vertex search operations (worst case, e.g. F) | 6 | 6 |

### Space requirements
- **Matrix:** always allocates V² cells regardless of how many edges actually exist — here 36 cells for only 6 edges, so 24 of the 36 cells (67%) are wasted zeros.
- **List:** allocates space proportional to 2E (each undirected edge stored once per endpoint) — only 12 cells for the same graph.
- For a **sparse** graph like this social network (E ≈ V, far fewer than the V(V−1)/2 = 15 possible edges), the list is dramatically more space-efficient.

### Traversal behaviour
- Both BFS and DFS visit vertices in the **same order** regardless of representation — traversal order depends on graph structure and neighbour-listing order, not on how edges are stored.
- However, the **work done per vertex differs**: with the matrix, visiting a vertex forces a scan of an entire row of length V (6 checks per vertex here, 36 total); with the list, only the vertex's actual neighbours are scanned (12 total, matching 2E).

### Search / edge-checking operations
- **Matrix:** O(1) to check if a specific edge (u, v) exists — just index `matrix[u][v]`.
- **List:** O(degree(u)) to check the same edge — must walk u's neighbour list.
- **Vertex existence search:** O(V) for both, since it depends on how vertex labels are stored/indexed (array or dict), not on the edge representation.

### Time complexity summary

| Operation | Adjacency Matrix | Adjacency List |
|---|---|---|
| Add vertex | O(V²) (resize matrix) | O(1) |
| Add edge | O(1) | O(1) |
| Check if edge exists | O(1) | O(degree(u)) |
| BFS / DFS (full traversal) | O(V²) | O(V + E) |
| Space | O(V²) | O(V + E) |

### Which representation is more suitable for a sparse social network?

**The adjacency list is more suitable.**

Justification from the execution results above:
1. **Space:** the list used only 12 storage cells versus 36 for the matrix — for a sparse graph (E ≪ V²), the matrix wastes memory on entries that will always be 0.
2. **Traversal efficiency:** BFS/DFS needed only 12 operations with the list versus 36 with the matrix, because the list lets traversal jump directly to real neighbours instead of scanning every possible vertex pair. This gives the list its well-known O(V + E) traversal complexity versus O(V²) for the matrix — a real gap once V grows, even though both took the same *order* of vertices here.
3. **Realistic scaling:** social networks are characteristically sparse (a person is connected to a small fraction of all other users, not everyone), so E grows roughly linearly with V rather than quadratically. The list's cost stays proportional to actual friendships/connections; the matrix's cost grows as the square of the user count regardless of how few connections exist.

The one place the matrix wins is **O(1) edge-existence checking** ("are these two people directly connected?"), which the list only does in O(degree(u)) — visible above where the B–F edge check took 3 operations on the list versus 1 on the matrix. If an application needed very frequent, ad-hoc "are X and Y connected?" queries on a graph that is not too large, the matrix's constant-time check could be worth its extra memory. But for a sparse social network where the priorities are **efficient storage and efficient traversal** (friend recommendations, shortest-connection-path, community detection), the adjacency list is the better overall choice.
