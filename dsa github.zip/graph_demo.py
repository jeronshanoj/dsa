# Social Network Graph: Adjacency Matrix vs Adjacency List
# Vertices: A, B, C, D, E, F
# Edges: A-B, A-C, B-D, B-E, C-F, E-F

vertices = ['A', 'B', 'C', 'D', 'E', 'F']
edges = [('A','B'), ('A','C'), ('B','D'), ('B','E'), ('C','F'), ('E','F')]
n = len(vertices)
idx = {v: i for i, v in enumerate(vertices)}

# ---------- 1. Adjacency Matrix ----------
matrix = [[0]*n for _ in range(n)]
matrix_ops = 0  # counts writes
for u, v in edges:
    i, j = idx[u], idx[v]
    matrix[i][j] = 1
    matrix[j][i] = 1
    matrix_ops += 2

print("Adjacency Matrix:")
print("   " + " ".join(vertices))
for i, row in enumerate(matrix):
    print(vertices[i], row)

# ---------- 2. Adjacency List ----------
adj_list = {v: [] for v in vertices}
list_ops = 0
for u, v in edges:
    adj_list[u].append(v)
    adj_list[v].append(u)
    list_ops += 2

print("\nAdjacency List:")
for v in vertices:
    print(f"{v}: {adj_list[v]}")

# ---------- 3. BFS ----------
def bfs_matrix(start):
    visited = [False]*n
    order = []
    ops = 0
    queue = [idx[start]]
    visited[idx[start]] = True
    while queue:
        u = queue.pop(0)
        order.append(vertices[u])
        for v in range(n):          # must scan ALL n columns
            ops += 1
            if matrix[u][v] == 1 and not visited[v]:
                visited[v] = True
                queue.append(v)
    return order, ops

def bfs_list(start):
    visited = {v: False for v in vertices}
    order = []
    ops = 0
    queue = [start]
    visited[start] = True
    while queue:
        u = queue.pop(0)
        order.append(u)
        for v in adj_list[u]:       # only scans actual neighbours
            ops += 1
            if not visited[v]:
                visited[v] = True
                queue.append(v)
    return order, ops

def dfs_matrix(start):
    visited = [False]*n
    order = []
    ops = 0
    def rec(u):
        nonlocal ops
        visited[idx[u]] = True
        order.append(u)
        for v in range(n):
            ops += 1
            if matrix[idx[u]][v] == 1 and not visited[v]:
                rec(vertices[v])
    rec(start)
    return order, ops

def dfs_list(start):
    visited = {v: False for v in vertices}
    order = []
    ops = 0
    def rec(u):
        nonlocal ops
        visited[u] = True
        order.append(u)
        for v in adj_list[u]:
            ops += 1
            if not visited[v]:
                rec(v)
    rec(start)
    return order, ops

bfs_m_order, bfs_m_ops = bfs_matrix('A')
bfs_l_order, bfs_l_ops = bfs_list('A')
dfs_m_order, dfs_m_ops = dfs_matrix('A')
dfs_l_order, dfs_l_ops = dfs_list('A')

print("\nBFS from A (Matrix):", bfs_m_order, "| cell-checks:", bfs_m_ops)
print("BFS from A (List)  :", bfs_l_order, "| neighbour-checks:", bfs_l_ops)
print("DFS from A (Matrix):", dfs_m_order, "| cell-checks:", dfs_m_ops)
print("DFS from A (List)  :", dfs_l_order, "| neighbour-checks:", dfs_l_ops)

# ---------- 4. Search operation: locate a specified vertex ----------
def search_matrix(target):
    """Search for a vertex 'target' as a row in the matrix (label lookup)."""
    ops = 0
    for i, v in enumerate(vertices):
        ops += 1
        if v == target:
            return i, ops
    return -1, ops

def search_list(target):
    """Search for a vertex key in the adjacency list dict."""
    ops = 0
    for v in adj_list.keys():
        ops += 1
        if v == target:
            return v, ops
    return None, ops

for target in ['E', 'F']:
    _, mops = search_matrix(target)
    _, lops = search_list(target)
    print(f"\nSearch for vertex '{target}':")
    print(f"  Adjacency Matrix -> comparisons: {mops}")
    print(f"  Adjacency List   -> comparisons: {lops}")

# ---------- 5. Edge-check example: is there an edge B-F? ----------
def edge_check_matrix(u, v):
    ops = 1
    return matrix[idx[u]][idx[v]] == 1, ops

def edge_check_list(u, v):
    ops = 0
    for x in adj_list[u]:
        ops += 1
        if x == v:
            return True, ops
    return False, ops

res_m = edge_check_matrix('B', 'F')
res_l = edge_check_list('B', 'F')
print(f"\nEdge check B-F -> Matrix: exists={res_m[0]}, ops={res_m[1]}")
print(f"Edge check B-F -> List:   exists={res_l[0]}, ops={res_l[1]}")

# ---------- 6. Space usage ----------
V = n
E = len(edges)
matrix_cells = V*V
list_cells = 2*E  # each undirected edge stored twice
print(f"\nVertices (V) = {V}, Edges (E) = {E}")
print(f"Matrix storage cells = V^2 = {matrix_cells}")
print(f"List storage cells   = 2E  = {list_cells}")
